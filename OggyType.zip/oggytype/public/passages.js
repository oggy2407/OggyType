// Passage sourcing for typing tests.
//
// We now pull real passages from DummyJSON's open, free quotes API
// (https://dummyjson.com/quotes/random — no key, no signup, CORS-enabled)
// so every test isn't the same 15 local sentences on repeat.
//
// But this project's original decision still stands: Quotable
// (api.quotable.io), the more commonly-suggested option, has a long,
// well-documented history of going down unpredictably. So the local
// PASSAGE_BANK below stays as an automatic fallback — if the API is
// slow, offline, or errors out, the test silently falls back to a local
// passage instead of leaving the user staring at a blank screen. This IS
// the "local fallback dataset" the project brief calls for; it just isn't
// the *only* source of text anymore.

const PASSAGE_BANK = [
  "The quick brown fox jumps over the lazy dog while the sun sets slowly behind the distant hills.",
  "Practice does not make perfect. Only perfect practice makes perfect, and perfect practice requires focus.",
  "Typing quickly is useful, but typing accurately is what actually saves you time in the long run.",
  "A journey of a thousand miles begins with a single step, and every expert was once a beginner.",
  "Good code is written for humans to read, and only incidentally for machines to execute correctly.",
  "The keyboard is one of the oldest human computer interfaces, yet it remains the fastest way to enter text.",
  "Consistency matters more than raw speed when you are first learning any new physical skill.",
  "Every great developer started out slow, hitting the wrong keys, before their fingers learned the way.",
  "Deep focus is a rare skill in a world full of notifications competing for your limited attention.",
  "Small improvements repeated daily eventually compound into results that once seemed impossible to reach.",
  "The night sky over the quiet village was filled with stars that seemed close enough to touch.",
  "Learning to type without looking down at your hands takes patience and a surprising amount of trust.",
  "Coffee shops full of quiet chatter are, for some reason, the ideal place for many people to concentrate.",
  "The old library smelled of dust and paper, a scent that somehow always meant comfort and calm.",
  "Programming is the art of telling another intelligence, precisely and patiently, exactly what you mean."
];

const REMOTE_QUOTE_API = "https://dummyjson.com/quotes/random";
const REMOTE_FETCH_TIMEOUT_MS = 2500; // don't let a slow API stall the start of a test

function getRandomPassage() {
  const index = Math.floor(Math.random() * PASSAGE_BANK.length);
  return PASSAGE_BANK[index];
}

// Tries the remote API once, with a timeout, and always resolves — it
// never rejects, so callers never need their own try/catch. Falls back
// to a local passage on any failure: network error, timeout, bad status,
// or a malformed/too-short response body.
async function fetchRemotePassage() {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), REMOTE_FETCH_TIMEOUT_MS);

  try {
    const res = await fetch(REMOTE_QUOTE_API, { signal: controller.signal });
    if (!res.ok) throw new Error(`Bad response: ${res.status}`);
    const data = await res.json();
    if (typeof data.quote !== "string" || data.quote.trim().length < 15) {
      throw new Error("Malformed quote payload");
    }
    return data.quote.trim();
  } catch (err) {
    console.warn("Remote passage unavailable, using a local passage instead:", err);
    return getRandomPassage();
  } finally {
    clearTimeout(timeoutId);
  }
}

// Builds enough text for a WORD-count test mode by pulling passages
// (remote-first, local-fallback) until we have enough words, then
// trimming to the exact requested count.
async function buildWordModeText(wordCount) {
  let words = [];
  while (words.length < wordCount) {
    const passage = await fetchRemotePassage();
    words = words.concat(passage.split(" "));
  }
  return words.slice(0, wordCount).join(" ");
}

// Builds enough text for a TIME-based test mode by chaining a few
// passages together (fetched in parallel) so the user never runs out
// of text mid-test.
async function buildTimeModeText() {
  const passages = await Promise.all([
    fetchRemotePassage(), fetchRemotePassage(), fetchRemotePassage()
  ]);
  return passages.join(" ");
}
