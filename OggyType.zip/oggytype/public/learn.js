/* =========================================================
   OGGYTYPE — LEARN MODULE
   ---------------------------------------------------------
   Self-contained, the same way passages.js/script.js are
   split: lessons.js holds data, this file holds behavior.
   Sections:
   1. State & elements
   2. Progress (localStorage)
   3. Lesson list rendering
   4. Keyboard + hand guide rendering
   5. Lesson practice (setup, render, input, finish)
   6. Wiring
   ========================================================= */

/* ---------- 1. STATE & ELEMENTS ---------- */
let learnState = {
  lesson: null,
  targetText: "",
  typedChars: [],
  currentIndex: 0,
  startTime: null,
  finished: false
};

const learnEls = {
  lessonList: document.getElementById("lesson-list"),
  practice: document.getElementById("lesson-practice"),
  complete: document.getElementById("lesson-complete"),
  title: document.getElementById("lesson-title"),
  wpm: document.getElementById("lesson-wpm"),
  accuracy: document.getElementById("lesson-accuracy"),
  progressFill: document.getElementById("lesson-progress-fill"),
  textDisplay: document.getElementById("lesson-text-display"),
  textLines: document.getElementById("lesson-text-lines"),
  caret: document.getElementById("lesson-caret"),
  hiddenInput: document.getElementById("lesson-hidden-input"),
  hint: document.querySelector("#lesson-practice .hint"),
  keyboard: document.getElementById("keyboard"),
  fingerHint: document.getElementById("finger-hint"),
  resultWpm: document.getElementById("lesson-result-wpm"),
  resultAccuracy: document.getElementById("lesson-result-accuracy"),
  resultBest: document.getElementById("lesson-result-best"),
};

let learnCaretIdleTimeout = null;
function markLearnCaretActive() {
  learnEls.caret.classList.remove("idle");
  clearTimeout(learnCaretIdleTimeout);
  learnCaretIdleTimeout = setTimeout(() => learnEls.caret.classList.add("idle"), 500);
}

/* ---------- 2. PROGRESS (localStorage) ---------- */
// Learn progress is separate from test History — it's per-lesson best
// scores, not a log of attempts, so it doesn't belong in the same
// backend table. Keeping it local keeps this module simple and self-
// contained; it could move to the backend later the same way test
// history did, without changing anything else here.
const LEARN_PROGRESS_KEY = "oggytype_learn_progress";

function loadLearnProgress() {
  try {
    return JSON.parse(localStorage.getItem(LEARN_PROGRESS_KEY)) || {};
  } catch {
    return {};
  }
}

function saveLearnProgress(progress) {
  localStorage.setItem(LEARN_PROGRESS_KEY, JSON.stringify(progress));
}

function recordLessonResult(lessonId, wpm, accuracy) {
  const progress = loadLearnProgress();
  const prev = progress[lessonId] || { bestWpm: 0, bestAccuracy: 0, attempts: 0 };
  progress[lessonId] = {
    bestWpm: Math.max(prev.bestWpm, wpm),
    bestAccuracy: Math.max(prev.bestAccuracy, accuracy),
    attempts: prev.attempts + 1,
    completed: true
  };
  saveLearnProgress(progress);
  return progress[lessonId];
}

/* ---------- 3. LESSON LIST ---------- */
function renderLessonList() {
  const progress = loadLearnProgress();
  learnEls.lessonList.innerHTML = "";

  LESSONS.forEach((lesson, i) => {
    const entry = progress[lesson.id];
    const card = document.createElement("button");
    card.className = "lesson-card" + (entry?.completed ? " completed" : "");
    card.style.setProperty("--i", i);
    card.innerHTML = `
      <div class="lesson-card-top">
        <span class="lesson-card-title">${lesson.title}</span>
        ${entry?.completed ? '<span class="lesson-check">✓</span>' : ""}
      </div>
      <p class="lesson-card-desc">${lesson.description}</p>
      <div class="lesson-card-stat">${entry ? `${entry.bestWpm} wpm best &middot; ${entry.bestAccuracy}% acc` : "Not started"}</div>
    `;
    card.addEventListener("click", () => openLesson(lesson));
    learnEls.lessonList.appendChild(card);
  });
}

function showLessonList() {
  learnEls.lessonList.classList.remove("hidden");
  learnEls.practice.classList.add("hidden");
  learnEls.complete.classList.add("hidden");
  renderLessonList();
}

/* ---------- 4. KEYBOARD + HAND GUIDE ---------- */
let keyboardBuilt = false;
function buildKeyboard() {
  if (keyboardBuilt) return;
  learnEls.keyboard.innerHTML = "";

  KEYBOARD_ROWS.forEach(row => {
    const rowEl = document.createElement("div");
    rowEl.className = "keyboard-row";
    row.forEach(key => {
      const keyEl = document.createElement("div");
      keyEl.className = "key" + (key === " " ? " key-space" : "");
      keyEl.dataset.key = key;
      keyEl.textContent = key === " " ? "space" : key;
      rowEl.appendChild(keyEl);
    });
    learnEls.keyboard.appendChild(rowEl);
  });
  keyboardBuilt = true;
}

// Highlights the key the user needs to press right now (solid) and the
// one after it (faint preview), and lights up the matching finger on
// the hand guide so the visual keyboard and the hand guide always agree.
function highlightTarget() {
  learnEls.keyboard.querySelectorAll(".key").forEach(k => k.classList.remove("active", "next"));
  document.querySelectorAll(".finger.active").forEach(f => f.classList.remove("active"));

  const current = learnState.targetText[learnState.currentIndex];
  const next = learnState.targetText[learnState.currentIndex + 1];
  if (current === undefined) {
    learnEls.fingerHint.textContent = "";
    return;
  }

  const currentKey = learnEls.keyboard.querySelector(`.key[data-key="${cssEscape(current.toLowerCase())}"]`);
  if (currentKey) currentKey.classList.add("active");

  if (next !== undefined) {
    const nextKey = learnEls.keyboard.querySelector(`.key[data-key="${cssEscape(next.toLowerCase())}"]`);
    if (nextKey) nextKey.classList.add("next");
  }

  const finger = KEY_FINGER_MAP[current.toLowerCase()];
  if (finger) {
    document.querySelectorAll(`.finger[data-finger="${finger}"]`).forEach(f => f.classList.add("active"));
    learnEls.fingerHint.textContent = current === " " ? "thumb — space" : `use your ${FINGER_LABELS[finger]}`;
  } else {
    learnEls.fingerHint.textContent = "";
  }
}

// Minimal CSS.escape polyfill fallback for the rare browser without it —
// keys here are just letters/space/punctuation so this is mostly a safety net.
function cssEscape(str) {
  return window.CSS && CSS.escape ? CSS.escape(str) : str.replace(/["\\]/g, "\\$&");
}

/* ---------- 5. LESSON PRACTICE ---------- */
function openLesson(lesson) {
  learnState.lesson = lesson;
  learnState.targetText = buildLessonText(lesson);
  learnState.typedChars = [];
  learnState.currentIndex = 0;
  learnState.startTime = null;
  learnState.finished = false;

  buildKeyboard();
  learnEls.title.textContent = lesson.title;
  learnEls.wpm.innerHTML = `0 <small>wpm</small>`;
  learnEls.accuracy.innerHTML = `100<small>%</small>`;
  learnEls.progressFill.style.width = "0%";
  learnEls.hint.classList.remove("hidden");
  learnEls.caret.classList.remove("idle");
  learnEls.hiddenInput.value = "";

  learnEls.lessonList.classList.add("hidden");
  learnEls.complete.classList.add("hidden");
  learnEls.practice.classList.remove("hidden");

  renderLessonText();
  requestAnimationFrame(() => {
    positionLearnCaret();
    highlightTarget();
    learnEls.hiddenInput.focus();
  });
}

function renderLessonText() {
  learnEls.textLines.innerHTML = "";
  const frag = document.createDocumentFragment();

  for (let i = 0; i < learnState.targetText.length; i++) {
    const span = document.createElement("span");
    span.className = "char";
    span.textContent = learnState.targetText[i];
    const typed = learnState.typedChars[i];
    if (typed) span.classList.add(typed.correct ? "correct" : "incorrect");
    frag.appendChild(span);
  }
  learnEls.textLines.appendChild(frag);
  positionLearnCaret();
}

// Same approach as the main test's caret, minus the 3-line scroll window —
// lesson text just wraps normally since there's no time pressure here.
function positionLearnCaret() {
  const chars = learnEls.textLines.querySelectorAll(".char");
  if (chars.length === 0) return;

  const atEnd = learnState.currentIndex >= chars.length;
  const refSpan = atEnd ? chars[chars.length - 1] : chars[learnState.currentIndex];
  const left = atEnd ? refSpan.offsetLeft + refSpan.offsetWidth : refSpan.offsetLeft;
  const top = refSpan.offsetTop;

  learnEls.caret.style.transform = `translate(${left}px, ${top}px)`;
  learnEls.caret.style.opacity = learnState.finished ? "0" : "1";
}

function learnElapsedSeconds() {
  if (learnState.startTime === null) return 0;
  return (Date.now() - learnState.startTime) / 1000;
}

function calculateLearnStats() {
  const elapsedMinutes = learnElapsedSeconds() / 60;
  let correct = 0, incorrect = 0;
  for (const entry of learnState.typedChars) {
    if (!entry) continue;
    if (entry.correct) correct++; else incorrect++;
  }
  const totalTyped = correct + incorrect;
  const wpm = elapsedMinutes <= 0 ? 0 : Math.round((correct / 5) / elapsedMinutes);
  const accuracy = totalTyped === 0 ? 100 : Math.round((correct / totalTyped) * 100);
  return { wpm, accuracy, correct, incorrect };
}

function updateLearnLiveStats() {
  const { wpm, accuracy } = calculateLearnStats();
  learnEls.wpm.innerHTML = `${wpm} <small>wpm</small>`;
  learnEls.accuracy.innerHTML = `${accuracy}<small>%</small>`;
  learnEls.progressFill.style.width = `${Math.min(100, (learnState.currentIndex / learnState.targetText.length) * 100)}%`;
}

learnEls.textDisplay.addEventListener("click", () => learnEls.hiddenInput.focus());

learnEls.hiddenInput.addEventListener("keydown", (e) => {
  if (learnState.finished) return;

  if (learnState.startTime === null && e.key.length === 1) {
    learnState.startTime = Date.now();
    learnEls.hint.classList.add("hidden");
  }

  if (e.key === "Backspace") {
    e.preventDefault();
    if (learnState.currentIndex > 0) {
      learnState.currentIndex--;
      learnState.typedChars[learnState.currentIndex] = undefined;
      renderLessonText();
      highlightTarget();
      updateLearnLiveStats();
    }
    markLearnCaretActive();
    return;
  }

  if (e.key.length !== 1) return;
  e.preventDefault();
  markLearnCaretActive();

  const expected = learnState.targetText[learnState.currentIndex];
  const correct = e.key === expected;
  learnState.typedChars[learnState.currentIndex] = { char: e.key, correct };
  learnState.currentIndex++;

  if (!correct) {
    learnEls.textDisplay.classList.remove("shake");
    void learnEls.textDisplay.offsetWidth;
    learnEls.textDisplay.classList.add("shake");
  }

  renderLessonText();
  highlightTarget();
  updateLearnLiveStats();

  if (learnState.currentIndex >= learnState.targetText.length) {
    finishLesson();
  }
});

function finishLesson() {
  learnState.finished = true;
  learnEls.caret.style.opacity = "0";

  const { wpm, accuracy } = calculateLearnStats();
  const updated = recordLessonResult(learnState.lesson.id, wpm, accuracy);

  learnEls.resultWpm.textContent = wpm;
  learnEls.resultAccuracy.textContent = accuracy + "%";
  learnEls.resultBest.textContent = updated.bestWpm;

  learnEls.practice.classList.add("hidden");
  learnEls.complete.classList.remove("hidden");
}

/* ---------- 6. WIRING ---------- */
document.getElementById("btn-lesson-back").addEventListener("click", showLessonList);
document.getElementById("btn-lesson-list").addEventListener("click", showLessonList);
document.getElementById("btn-lesson-retry").addEventListener("click", () => openLesson(learnState.lesson));

document.getElementById("btn-lesson-next").addEventListener("click", () => {
  const idx = LESSONS.findIndex(l => l.id === learnState.lesson.id);
  const next = LESSONS[idx + 1];
  if (next) openLesson(next); else showLessonList();
});

// Entry point called from script.js's nav handler when the Learn tab
// is selected. Exposed on window so script.js doesn't need to know
// anything about this module's internals beyond this one function.
window.initLearnView = function () {
  buildKeyboard();
  showLessonList();
};
