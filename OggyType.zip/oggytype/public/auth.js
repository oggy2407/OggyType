/* =========================================================
   OGGYTYPE — AUTH (lightweight, no password)
   ---------------------------------------------------------
   Not real authentication — there's no server-side account
   system. What this does: ask for a display name once, and
   pair it with a randomly-generated unique id (crypto.randomUUID)
   stored in this browser's localStorage. Every request to the
   backend carries that id (see getClientId() in script.js), so
   each person's Test History and Learn progress stay separate
   from everyone else's, without needing real signup/login.
   ========================================================= */

const USER_NAME_KEY = "oggytype_user_name";
const CLIENT_ID_KEY = "oggytype_client_id";

const authEls = {
  loginScreen: document.getElementById("login-screen"),
  nameInput: document.getElementById("login-name-input"),
  startBtn: document.getElementById("login-start-btn"),
  navUsername: document.getElementById("nav-username"),
  switchBtn: document.getElementById("btn-switch-user"),
};

function getUserName() {
  return localStorage.getItem(USER_NAME_KEY);
}

// Called by script.js too (saveAttempt/renderHistory) so every request
// carries the same id. Generates one the first time it's needed.
function getClientId() {
  let id = localStorage.getItem(CLIENT_ID_KEY);
  if (!id) {
    id = crypto.randomUUID
      ? crypto.randomUUID()
      : `client-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    localStorage.setItem(CLIENT_ID_KEY, id);
  }
  return id;
}

function completeLogin(name) {
  localStorage.setItem(USER_NAME_KEY, name);
  getClientId(); // make sure a unique id exists as soon as someone logs in
  authEls.navUsername.textContent = name;
  authEls.loginScreen.classList.add("hidden");
}

function submitLogin() {
  const name = authEls.nameInput.value.trim();
  if (!name) {
    authEls.nameInput.classList.remove("shake-anim");
    void authEls.nameInput.offsetWidth; // restart the animation on repeated empty submits
    authEls.nameInput.classList.add("shake-anim");
    return;
  }
  completeLogin(name);
}

authEls.startBtn.addEventListener("click", submitLogin);
authEls.nameInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    submitLogin();
  }
});

// "Switch" clears the stored identity entirely (name + id), so the next
// person gets a genuinely fresh, separate history rather than inheriting
// the previous person's saved runs.
authEls.switchBtn.addEventListener("click", () => {
  localStorage.removeItem(USER_NAME_KEY);
  localStorage.removeItem(CLIENT_ID_KEY);
  location.reload();
});

// On load: skip straight past the login screen if this browser already
// has a name saved, otherwise show it and focus the input.
const existingName = getUserName();
if (existingName) {
  authEls.navUsername.textContent = existingName;
} else {
  authEls.loginScreen.classList.remove("hidden");
  authEls.nameInput.focus();
}
