/* =========================================================
   LESSON DATA
   ---------------------------------------------------------
   Keyboard layout for rendering the visual keyboard, the
   key -> finger mapping that drives the hand guide, and the
   lesson list itself. Kept separate from learn.js the same
   way passages.js is kept separate from script.js — data
   here, behavior there.
   ========================================================= */

// Rows for the on-screen keyboard. Each row is left-to-right as on a
// real keyboard. We only render letters, space, and a few punctuation
// keys the word-based lessons use — no need to model the full keyboard.
const KEYBOARD_ROWS = [
  ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
  ["a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'"],
  ["z", "x", "c", "v", "b", "n", "m", ",", "."],
  [" "]
];

// Standard touch-typing finger assignments.
const KEY_FINGER_MAP = {
  "q": "left-pinky",  "a": "left-pinky",  "z": "left-pinky",
  "w": "left-ring",   "s": "left-ring",   "x": "left-ring",
  "e": "left-middle", "d": "left-middle", "c": "left-middle",
  "r": "left-index",  "f": "left-index",  "v": "left-index",
  "t": "left-index",  "g": "left-index",  "b": "left-index",
  "y": "right-index", "h": "right-index", "n": "right-index",
  "u": "right-index", "j": "right-index", "m": "right-index",
  "i": "right-middle", "k": "right-middle", ",": "right-middle",
  "o": "right-ring",   "l": "right-ring",   ".": "right-ring",
  "p": "right-pinky",  ";": "right-pinky",  "'": "right-pinky",
  " ": "left-thumb"
};

// Human-readable finger names for the on-screen label.
const FINGER_LABELS = {
  "left-pinky": "left pinky",   "left-ring": "left ring finger",
  "left-middle": "left middle finger", "left-index": "left index finger",
  "left-thumb": "either thumb",
  "right-index": "right index finger", "right-middle": "right middle finger",
  "right-ring": "right ring finger",   "right-pinky": "right pinky",
  "right-thumb": "either thumb"
};

// Word banks for the lessons that practice real words instead of raw
// key drills. Each is restricted to keys the lesson has introduced so
// far, so the words are actually typeable with what's been taught.
const WORD_BANKS = {
  homeRow: ["ask", "flask", "gash", "glad", "half", "lash", "sad", "salad", "flag", "gall", "hall", "jak", "lag", "dash"],
  allLetters: ["the", "quick", "brown", "fox", "jumps", "over", "lazy", "dog", "type", "with", "focus", "learn", "every", "key", "build", "speed", "and", "control", "practice", "makes", "progress"],
  punctuation: ["well,", "yes.", "it's", "don't", "wait,", "okay.", "hello,", "she's", "that's", "right.", "stop,", "let's", "can't", "sure."]
};

const LESSONS = [
  {
    id: "home-row",
    title: "Home Row",
    description: "Rest your fingers on A S D F  J K L ; and get comfortable with the base position.",
    keys: "asdfjkl;",
    kind: "drill"
  },
  {
    id: "top-row",
    title: "Top Row",
    description: "Reach up from the home row to Q W E R T  Y U I O P.",
    keys: "asdfjkl;qwertyuiop",
    kind: "drill"
  },
  {
    id: "bottom-row",
    title: "Bottom Row",
    description: "Reach down to Z X C V B  N M , . and back to home each time.",
    keys: "asdfjkl;zxcvbnm,.",
    kind: "drill"
  },
  {
    id: "home-row-words",
    title: "Home Row Words",
    description: "Real words using only the keys you've learned so far.",
    kind: "words",
    bank: "homeRow"
  },
  {
    id: "all-letters",
    title: "All Letters",
    description: "Every letter key, in real words at a natural pace.",
    kind: "words",
    bank: "allLetters"
  },
  {
    id: "punctuation",
    title: "Punctuation",
    description: "Commas, periods, and apostrophes without breaking rhythm.",
    kind: "words",
    bank: "punctuation"
  }
];

// Builds a character-drill string for "drill" lessons: short random
// clusters of the lesson's keys, space-separated so it reads (and
// highlights) like the word-based lessons do.
function buildDrillText(keys, targetLength = 140) {
  const pool = keys.split("");
  let out = "";
  while (out.length < targetLength) {
    const clusterLen = 2 + Math.floor(Math.random() * 3); // 2-4 chars
    let cluster = "";
    for (let i = 0; i < clusterLen; i++) {
      cluster += pool[Math.floor(Math.random() * pool.length)];
    }
    out += (out.length ? " " : "") + cluster;
  }
  return out.slice(0, targetLength).trim();
}

// Builds word-based text by sampling from a word bank until we have
// enough words for a reasonable lesson length.
function buildWordsText(bankName, wordCount = 22) {
  const bank = WORD_BANKS[bankName];
  const words = [];
  for (let i = 0; i < wordCount; i++) {
    words.push(bank[Math.floor(Math.random() * bank.length)]);
  }
  return words.join(" ");
}

function buildLessonText(lesson) {
  return lesson.kind === "drill"
    ? buildDrillText(lesson.keys)
    : buildWordsText(lesson.bank);
}
