/* =========================================================
   OGGYTYPE — TYPING ENGINE
   ---------------------------------------------------------
   This file is organized into sections:
   1. State           - variables that track the current test
   2. Setup            - building a new test (new passage, reset state)
   3. Input handling    - what happens as the user types
   4. Scoring           - WPM / accuracy / consistency math
   5. Timer             - the countdown / elapsed time loop
   6. Finish            - ending the test and showing results
   7. History            - saving/loading past attempts
   8. Wiring             - connecting buttons etc to the functions above
   ========================================================= */

/* ---------- 1. STATE ---------- */
// All the "current test" data lives in one object so it's easy to
// reset between tests and easy to reason about.
let state = {
  mode: "time",        // "time" or "words"
  modeValue: 15,        // seconds (time mode) or word count (words mode)
  targetText: "",        // the passage the user is typing
  typedChars: [],          // array of {char, correct} for each position typed
  currentIndex: 0,           // index of the next character to type
  startTime: null,             // timestamp when typing started (first keystroke)
  timerInterval: null,          // setInterval handle for the countdown/live stats
  timeRemaining: 0,               // seconds left (time mode only)
  wpmSnapshots: [],                // [{ t: secondsElapsed, wpm: number }] for the graph
  finished: false
};

const els = {
  textDisplay: document.getElementById("text-display"),
  textLines: document.getElementById("text-lines"),
  caret: document.getElementById("caret"),
  hiddenInput: document.getElementById("hidden-input"),
  hint: document.querySelector(".hint"),
  liveStats: document.getElementById("live-stats"),
  liveWpm: document.getElementById("live-wpm"),
  liveAccuracy: document.getElementById("live-accuracy"),
  liveTimer: document.getElementById("live-timer"),
  typingScreen: document.getElementById("typing-screen"),
  resultScreen: document.getElementById("result-screen"),
  historyScreen: document.getElementById("history-screen"),
  learnScreen: document.getElementById("learn-screen"),
  modeBar: document.getElementById("mode-bar"),
  modePill: document.getElementById("mode-pill"),
  progressTrack: document.querySelector(".progress-track"),
  progressFill: document.getElementById("progress-fill"),
};

// Tracks the last value shown for each live stat so we only "pulse" a
// number when it actually changes, not on every 250ms tick.
const lastShown = { wpm: null, accuracy: null };

// While the user is actively typing we keep the caret solid — it only
// starts blinking once they pause. Small thing, but it's the difference
// between the caret feeling like part of the typing motion vs. a
// separate blinking widget sitting on top of it.
let caretIdleTimeout = null;
function markCaretActive() {
  els.caret.classList.remove("idle");
  clearTimeout(caretIdleTimeout);
  caretIdleTimeout = setTimeout(() => els.caret.classList.add("idle"), 500);
}

/* ---------- 2. SETUP ---------- */
// Guards against overlapping calls if the user mashes Tab or a mode
// button again while a previous request is still in flight.
let isLoadingText = false;

async function startNewTest() {
  if (isLoadingText) return;
  isLoadingText = true;

  // Passages now come from a remote API first (see passages.js), which
  // means fetching them takes a beat. Keep the typing area visible but
  // say so, rather than leaving it blank while we wait.
  els.hiddenInput.disabled = true;
  els.hint.innerHTML = "Loading passage&hellip;";
  els.hint.classList.remove("hidden");
  els.typingScreen.classList.remove("hidden");
  els.resultScreen.classList.add("hidden");
  els.historyScreen.classList.add("hidden");
  els.modeBar.classList.remove("hidden");

  const text = state.mode === "words"
    ? await buildWordModeText(state.modeValue)
    : await buildTimeModeText();

  state.targetText = text;
  state.typedChars = [];
  state.currentIndex = 0;
  state.startTime = null;
  state.timeRemaining = state.modeValue;
  state.wpmSnapshots = [];
  state.finished = false;

  clearInterval(state.timerInterval);
  state.timerInterval = null;

  renderText();
  els.liveTimer.textContent = state.mode === "time" ? state.timeRemaining : "0";
  els.liveWpm.textContent = "0";
  els.liveAccuracy.textContent = "100%";
  lastShown.wpm = null;
  lastShown.accuracy = null;

  els.liveStats.classList.add("hidden");
  els.hint.innerHTML = "Click here and start typing to begin — press <kbd>Tab</kbd> to restart";
  els.progressTrack.classList.remove("visible");
  els.progressFill.style.width = "0%";
  els.caret.classList.remove("idle");
  clearTimeout(caretIdleTimeout);

  els.hiddenInput.value = "";
  els.hiddenInput.disabled = false;
  isLoadingText = false;

  // Position the mode pill and caret only after the browser has painted
  // the current layout, otherwise the measurements below are stale.
  requestAnimationFrame(() => {
    moveModePill(document.querySelector(".mode-btn.active"));
    positionCaret();
  });
}

function renderText() {
  els.textLines.innerHTML = "";
  const frag = document.createDocumentFragment();

  for (let i = 0; i < state.targetText.length; i++) {
    const span = document.createElement("span");
    span.className = "char";
    span.textContent = state.targetText[i];

    const typed = state.typedChars[i];
    if (typed) {
      span.classList.add(typed.correct ? "correct" : "incorrect");
    }
    frag.appendChild(span);
  }
  els.textLines.appendChild(frag);
  positionCaret();
}

// Moves the single caret element to sit right before the current
// character (or at the very end of the text once finished). Also keeps
// the 3-line window scrolled so the active line is always visible,
// sliding smoothly rather than jumping when a new line comes into play.
function positionCaret() {
  const chars = els.textLines.querySelectorAll(".char");
  if (chars.length === 0) return;

  const atEnd = state.currentIndex >= chars.length;
  const refSpan = atEnd ? chars[chars.length - 1] : chars[state.currentIndex];
  const left = atEnd ? refSpan.offsetLeft + refSpan.offsetWidth : refSpan.offsetLeft;
  const top = refSpan.offsetTop;
  const lineHeight = refSpan.offsetHeight || 1;

  // The caret lives outside .text-lines (so it doesn't get clipped by
  // its own scroll transform), so its vertical position has to be given
  // relative to the *visible window*, not the untransformed text — i.e.
  // we subtract the same scroll offset we're about to apply below.
  const row = Math.floor(top / lineHeight);
  const visibleTop = top - row * lineHeight;

  els.caret.style.transform = `translate(${left}px, ${visibleTop}px)`;
  els.caret.style.opacity = state.finished ? "0" : "1";
  els.textLines.style.transform = `translateY(${-row * lineHeight}px)`;
}

/* ---------- 3. INPUT HANDLING ---------- */
els.textDisplay.addEventListener("click", () => els.hiddenInput.focus());

els.hiddenInput.addEventListener("keydown", (e) => {
  if (state.finished) return;

  // Tab restarts the test instantly, mirroring the convention most
  // typing tests use so a redo never requires reaching for the mouse.
  if (e.key === "Tab") {
    e.preventDefault();
    startNewTest();
    return;
  }

  // Start the timer on the very first keystroke, not on page load.
  if (state.startTime === null && e.key.length === 1) {
    beginTiming();
  }

  if (e.key === "Backspace") {
    e.preventDefault();
    if (state.currentIndex > 0) {
      state.currentIndex--;
      state.typedChars[state.currentIndex] = undefined;
      renderText();
    }
    markCaretActive();
    return;
  }

  // Ignore modifier/navigation keys - only handle printable characters.
  if (e.key.length !== 1) return;
  e.preventDefault();
  markCaretActive();

  const expected = state.targetText[state.currentIndex];
  const correct = e.key === expected;

  state.typedChars[state.currentIndex] = { char: e.key, correct };
  state.currentIndex++;

  if (!correct) {
    els.textDisplay.classList.remove("shake");
    // Force reflow so the animation can restart on back-to-back mistakes.
    void els.textDisplay.offsetWidth;
    els.textDisplay.classList.add("shake");
  }

  renderText();
  updateLiveStats();
  updateProgress();

  // Word mode ends when the user reaches the end of the text.
  if (state.mode === "words" && state.currentIndex >= state.targetText.length) {
    finishTest();
  }
});

/* ---------- 4. SCORING ---------- */
// Standard convention: WPM = (correct characters / 5) / minutes elapsed.
// We use CORRECT characters only for the headline WPM (this rewards
// accuracy, not just speed), and separately track "raw WPM" using all
// typed characters including mistakes.
function calculateStats() {
  const elapsedMinutes = getElapsedSeconds() / 60;
  if (elapsedMinutes <= 0) return { wpm: 0, rawWpm: 0, accuracy: 100, correct: 0, incorrect: 0 };

  let correct = 0;
  let incorrect = 0;
  for (const entry of state.typedChars) {
    if (!entry) continue;
    if (entry.correct) correct++;
    else incorrect++;
  }
  const totalTyped = correct + incorrect;

  const wpm = Math.round((correct / 5) / elapsedMinutes);
  const rawWpm = Math.round((totalTyped / 5) / elapsedMinutes);
  const accuracy = totalTyped === 0 ? 100 : Math.round((correct / totalTyped) * 100);

  return { wpm, rawWpm, accuracy, correct, incorrect };
}

function getElapsedSeconds() {
  if (state.startTime === null) return 0;
  return (Date.now() - state.startTime) / 1000;
}

// Consistency: how steady the user's WPM was during the test.
// We measure it as 100% minus the coefficient of variation of the
// WPM snapshots (lower variation = higher consistency).
function calculateConsistency() {
  const values = state.wpmSnapshots.map(s => s.wpm).filter(v => v > 0);
  if (values.length < 2) return 100;

  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  const stdDev = Math.sqrt(variance);
  const coefficientOfVariation = mean === 0 ? 0 : stdDev / mean;

  const consistency = Math.max(0, Math.round(100 - coefficientOfVariation * 100));
  return consistency;
}

/* ---------- 5. TIMER ---------- */
function beginTiming() {
  state.startTime = Date.now();
  els.liveStats.classList.remove("hidden");
  els.hint.classList.add("hidden");
  els.progressTrack.classList.add("visible");

  state.timerInterval = setInterval(() => {
    if (state.mode === "time") {
      const elapsed = Math.floor(getElapsedSeconds());
      state.timeRemaining = Math.max(0, state.modeValue - elapsed);
      els.liveTimer.textContent = state.timeRemaining;
      if (state.timeRemaining <= 0) {
        finishTest();
        return;
      }
    } else {
      els.liveTimer.textContent = Math.floor(getElapsedSeconds());
    }
    updateLiveStats();
    updateProgress();
  }, 250);
}

function updateLiveStats() {
  const stats = calculateStats();
  setStatValue(els.liveWpm, stats.wpm, "wpm");
  setStatValue(els.liveAccuracy, stats.accuracy + "%", "accuracy");

  // Record a snapshot roughly once per second for the graph, keyed by
  // whole seconds so we don't flood the array from the 250ms tick.
  const second = Math.floor(getElapsedSeconds());
  const last = state.wpmSnapshots[state.wpmSnapshots.length - 1];
  if (!last || last.t !== second) {
    state.wpmSnapshots.push({ t: second, wpm: stats.wpm });
  } else {
    last.wpm = stats.wpm;
  }
}

// Updates a live stat's text, but only triggers the little "pulse" pop
// when the displayed value actually changed — otherwise every 250ms
// tick would pulse the number even while it's sitting still.
function setStatValue(el, value, key) {
  if (lastShown[key] === value) return;
  lastShown[key] = value;
  el.textContent = value;
  el.classList.remove("pulse");
  void el.offsetWidth;
  el.classList.add("pulse");
}

// Fills the thin progress bar above the text: time-remaining for timed
// tests, characters-typed for word-count tests. Smoothly tracked via a
// CSS transition rather than being redrawn from scratch each tick.
function updateProgress() {
  let pct = 0;
  if (state.mode === "time") {
    pct = Math.min(100, (getElapsedSeconds() / state.modeValue) * 100);
  } else {
    pct = Math.min(100, (state.currentIndex / state.targetText.length) * 100);
  }
  els.progressFill.style.width = pct + "%";
}

/* ---------- 6. FINISH ---------- */
function finishTest() {
  state.finished = true;
  clearInterval(state.timerInterval);

  const stats = calculateStats();
  const consistency = calculateConsistency();
  const durationSeconds = Math.round(getElapsedSeconds());

  const attempt = {
    date: new Date().toISOString(),
    mode: state.mode === "time" ? `${state.modeValue}s` : `${state.modeValue} words`,
    wpm: stats.wpm,
    rawWpm: stats.rawWpm,
    accuracy: stats.accuracy,
    consistency,
    correct: stats.correct,
    incorrect: stats.incorrect,
    duration: durationSeconds,
    snapshots: state.wpmSnapshots
  };

  saveAttempt(attempt);
  renderText();
  showResults(attempt);
}

function showResults(attempt) {
  els.typingScreen.classList.add("hidden");
  els.modeBar.classList.add("hidden");
  els.liveStats.classList.add("hidden");
  els.resultScreen.classList.remove("hidden");

  document.getElementById("result-wpm").textContent = attempt.wpm;
  document.getElementById("result-accuracy").textContent = attempt.accuracy + "%";
  document.getElementById("result-raw-wpm").textContent = attempt.rawWpm;
  document.getElementById("result-consistency").textContent = attempt.consistency + "%";
  document.getElementById("result-correct").textContent = attempt.correct;
  document.getElementById("result-incorrect").textContent = attempt.incorrect;
  document.getElementById("result-duration").textContent = attempt.duration + "s";

  // Re-trigger the staggered reveal animation every time results show,
  // and give each block an increasing delay via --i so they cascade in
  // left-to-right instead of all popping at once.
  document.querySelectorAll(".result-block").forEach((block, i) => {
    block.style.setProperty("--i", i);
    block.style.animation = "none";
    void block.offsetWidth;
    block.style.animation = "";
  });

  drawGraph(attempt.snapshots);
}

let graphInstance = null;
function drawGraph(snapshots) {
  const ctx = document.getElementById("wpm-graph").getContext("2d");
  if (graphInstance) graphInstance.destroy();

  graphInstance = new Chart(ctx, {
    type: "line",
    data: {
      labels: snapshots.map(s => s.t + "s"),
      datasets: [{
        label: "WPM",
        data: snapshots.map(s => s.wpm),
        borderColor: "#e8a94c",
        backgroundColor: "rgba(232, 169, 76, 0.1)",
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.3,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: "#2a2a30" }, ticks: { color: "#5c5c66" } },
        y: { grid: { color: "#2a2a30" }, ticks: { color: "#5c5c66" }, beginAtZero: true }
      }
    }
  });
}

/* ---------- 7. HISTORY ---------- */
// Attempts are saved to the backend (SQLite via /api/attempts) so history
// persists across sessions. Each browser has a name + unique id assigned
// at login (see auth.js — getClientId() lives there), sent as the
// X-Client-Id / X-Client-Name headers, so your history doesn't mix with
// anyone else's. If the server isn't reachable, everything falls back to
// localStorage so the app still works standalone.
const HISTORY_KEY = "oggytype_history";

async function saveAttempt(attempt) {
  try {
    const res = await fetch("/api/attempts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Client-Id": getClientId(),
        "X-Client-Name": getUserName() || "anonymous"
      },
      body: JSON.stringify(attempt)
    });
    if (!res.ok) throw new Error("Server rejected the attempt");
  } catch (err) {
    console.warn("Backend unreachable, saving attempt locally instead:", err);
    saveAttemptLocal(attempt);
  }
}

function saveAttemptLocal(attempt) {
  const history = loadHistoryLocal();
  history.unshift(attempt);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 100)));
}

function loadHistoryLocal() {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY)) || [];
  } catch {
    return [];
  }
}

async function renderHistory() {
  const empty = document.getElementById("history-empty");
  const table = document.getElementById("history-table");
  const body = document.getElementById("history-body");

  let history;
  try {
    const res = await fetch("/api/attempts", {
      headers: { "X-Client-Id": getClientId() }
    });
    if (!res.ok) throw new Error("Failed to fetch history");
    history = await res.json();
  } catch (err) {
    console.warn("Backend unreachable, showing local history instead:", err);
    history = loadHistoryLocal();
  }

  if (history.length === 0) {
    empty.classList.remove("hidden");
    table.classList.add("hidden");
    return;
  }

  empty.classList.add("hidden");
  table.classList.remove("hidden");
  body.innerHTML = "";

  for (const a of history) {
    const row = document.createElement("tr");
    const date = new Date(a.date);
    row.innerHTML = `
      <td>${date.toLocaleDateString()} ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</td>
      <td>${a.mode}</td>
      <td>${a.wpm}</td>
      <td>${a.accuracy}%</td>
      <td>${a.incorrect}</td>
    `;
    body.appendChild(row);
  }
}

/* ---------- 8. WIRING ---------- */

// Slides the mode-bar highlight under whichever button is active,
// measured in real pixels so it lines up exactly regardless of label
// width ("15s" vs "50 words").
function moveModePill(btn) {
  if (!btn) return;
  const barRect = els.modeBar.getBoundingClientRect();
  const btnRect = btn.getBoundingClientRect();
  els.modePill.style.width = btnRect.width + "px";
  els.modePill.style.height = btnRect.height + "px";
  els.modePill.style.top = (btnRect.top - barRect.top) + "px";
  els.modePill.style.transform = `translateX(${btnRect.left - barRect.left}px)`;
}

document.querySelectorAll(".mode-btn:not(.mode-custom)").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    moveModePill(btn);
    state.mode = btn.dataset.mode;
    state.modeValue = parseInt(btn.dataset.value, 10);

    // Selecting a preset resets any custom value that was showing, and
    // closes any open popover so the two controls don't get out of sync.
    document.getElementById("custom-time-btn").textContent = "+ custom";
    document.getElementById("custom-words-btn").textContent = "+ custom";
    document.querySelectorAll(".custom-popover").forEach(p => p.classList.add("hidden"));

    startNewTest();
  });
});

// Custom time/word length: clicking "+ custom" reveals a small inline
// input instead of a picker with endless preset buttons. Pressing Enter
// (or the Set button) applies it as the active mode, same as any preset.
function wireCustomMode({ btnId, popoverId, inputId, applyId, mode, min, max }) {
  const btn = document.getElementById(btnId);
  const popover = document.getElementById(popoverId);
  const input = document.getElementById(inputId);
  const apply = document.getElementById(applyId);

  function applyValue() {
    const value = parseInt(input.value, 10);
    if (!Number.isFinite(value) || value < min || value > max) {
      input.classList.remove("shake-anim");
      void input.offsetWidth;
      input.classList.add("shake-anim");
      return;
    }

    document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
    btn.textContent = mode === "time" ? `${value}s` : `${value} words`;
    btn.classList.add("active");
    moveModePill(btn);
    popover.classList.add("hidden");

    state.mode = mode;
    state.modeValue = value;
    startNewTest();
  }

  btn.addEventListener("click", () => {
    document.querySelectorAll(".custom-popover").forEach(p => {
      if (p !== popover) p.classList.add("hidden");
    });
    popover.classList.toggle("hidden");
    if (!popover.classList.contains("hidden")) {
      input.value = "";
      input.focus();
    }
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      applyValue();
    }
  });

  apply.addEventListener("click", applyValue);
}

wireCustomMode({
  btnId: "custom-time-btn", popoverId: "custom-time-popover",
  inputId: "custom-time-value", applyId: "custom-time-apply",
  mode: "time", min: 5, max: 600
});
wireCustomMode({
  btnId: "custom-words-btn", popoverId: "custom-words-popover",
  inputId: "custom-words-value", applyId: "custom-words-apply",
  mode: "words", min: 3, max: 300
});

// Keep the pill and caret aligned with their targets if the window
// resizes (e.g. rotating a tablet, or resizing a browser window).
window.addEventListener("resize", () => {
  moveModePill(document.querySelector(".mode-btn.active"));
  if (!els.typingScreen.classList.contains("hidden")) positionCaret();
});

document.getElementById("btn-restart").addEventListener("click", startNewTest);
document.getElementById("btn-new-test").addEventListener("click", startNewTest);

document.querySelectorAll(".nav-link").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    document.querySelectorAll(".nav-link").forEach(l => l.classList.remove("active"));
    link.classList.add("active");

    const view = link.dataset.view;

    // Hide every top-level view first, then reveal just the one we want —
    // simpler to reason about than toggling each screen individually as
    // the number of views grows.
    els.typingScreen.classList.add("hidden");
    els.modeBar.classList.add("hidden");
    els.liveStats.classList.add("hidden");
    els.resultScreen.classList.add("hidden");
    els.historyScreen.classList.add("hidden");
    els.learnScreen.classList.add("hidden");

    if (view === "history") {
      els.historyScreen.classList.remove("hidden");
      renderHistory();
    } else if (view === "learn") {
      els.learnScreen.classList.remove("hidden");
      window.initLearnView();
    } else {
      startNewTest();
    }
  });
});

// Keep focus on the hidden input whenever the typing screen is visible,
// so the user can just start typing without needing to click first.
// Also catches Tab as a global "restart" shortcut even if focus landed
// somewhere else (e.g. right after finishing a test).
//
// IMPORTANT: the typing screen sits visible underneath things like the
// login overlay and the custom time/word popovers, so without a guard
// here, every keystroke typed into THOSE inputs would get redirected
// into the hidden test input instead — silently corrupting whatever the
// user actually meant to type. Skip entirely whenever focus is already
// on some other real input/textarea.
document.addEventListener("keydown", (e) => {
  const active = document.activeElement;
  const typingElsewhere = active && active !== els.hiddenInput &&
    (active.tagName === "INPUT" || active.tagName === "TEXTAREA");
  if (typingElsewhere) return;

  const onTypingOrResults = !els.typingScreen.classList.contains("hidden") ||
    !els.resultScreen.classList.contains("hidden");

  if (e.key === "Tab" && onTypingOrResults) {
    e.preventDefault();
    startNewTest();
    return;
  }

  if (!els.typingScreen.classList.contains("hidden")) {
    els.hiddenInput.focus();
  }
});

/* ---------- INIT ---------- */
startNewTest();