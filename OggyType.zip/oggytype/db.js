/* =========================================================
   DATABASE SETUP
   ---------------------------------------------------------
   Uses better-sqlite3 (synchronous, no native-binding
   headaches for a project this size). The .db file is
   created automatically the first time the server runs —
   nothing to install or configure beyond `npm install`.
   ========================================================= */

const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "oggytype.db"));

// WAL mode = readers and writers don't block each other, and it survives
// unclean shutdowns better than the default journal mode.
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS attempts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      TEXT    NOT NULL DEFAULT 'anonymous',
    user_name    TEXT    NOT NULL DEFAULT 'anonymous',
    date         TEXT    NOT NULL,
    mode         TEXT    NOT NULL,
    wpm          INTEGER NOT NULL,
    raw_wpm      INTEGER NOT NULL,
    accuracy     INTEGER NOT NULL,
    consistency  INTEGER NOT NULL,
    correct      INTEGER NOT NULL,
    incorrect    INTEGER NOT NULL,
    duration     INTEGER NOT NULL,
    snapshots    TEXT    NOT NULL
  )
`);

// Migration for anyone who already ran the server before these columns
// existed — CREATE TABLE IF NOT EXISTS above won't add a column to an
// existing table, so check for it explicitly and add it if missing.
const columns = db.prepare("PRAGMA table_info(attempts)").all();
const columnNames = columns.map(c => c.name);
if (!columnNames.includes("user_id")) {
  db.exec(`ALTER TABLE attempts ADD COLUMN user_id TEXT NOT NULL DEFAULT 'anonymous'`);
}
if (!columnNames.includes("user_name")) {
  db.exec(`ALTER TABLE attempts ADD COLUMN user_name TEXT NOT NULL DEFAULT 'anonymous'`);
}

db.exec(`CREATE INDEX IF NOT EXISTS idx_attempts_user_id ON attempts (user_id)`);

module.exports = db;
