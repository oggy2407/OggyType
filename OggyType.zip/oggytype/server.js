/* =========================================================
   OGGYTYPE — SERVER
   ---------------------------------------------------------
   Serves the static frontend (public/) and exposes a small
   JSON API for saving and retrieving typing test attempts.
   Everything is same-origin, so the frontend just calls
   fetch("/api/attempts") with no CORS setup needed.
   ========================================================= */

const express = require("express");
const path = require("path");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

/* ---------- API ---------- */

// Every request carries an X-Client-Id header — a UUID the frontend
// generates once and stores in localStorage — and an X-Client-Name header
// with the display name chosen at login. Not real authentication, just a
// stable anonymous identifier so each browser gets its own history
// instead of everyone's attempts landing in one shared pile. Swap this out
// for a real logged-in user id once auth exists — nothing else changes.
function getClientId(req) {
  const id = req.get("X-Client-Id");
  return (typeof id === "string" && id.trim()) ? id.trim() : "anonymous";
}

function getClientName(req) {
  const name = req.get("X-Client-Name");
  return (typeof name === "string" && name.trim()) ? name.trim().slice(0, 24) : "anonymous";
}

// Save a completed test attempt.
app.post("/api/attempts", (req, res) => {
  const {
    date, mode, wpm, rawWpm, accuracy,
    consistency, correct, incorrect, duration, snapshots
  } = req.body || {};

  // Don't trust the client — reject anything that doesn't look like a
  // real attempt rather than silently inserting bad rows.
  const isValid =
    typeof mode === "string" && mode.length > 0 &&
    [wpm, rawWpm, accuracy, consistency, correct, incorrect, duration]
      .every(Number.isFinite);

  if (!isValid) {
    return res.status(400).json({ error: "Invalid attempt payload" });
  }

  const stmt = db.prepare(`
    INSERT INTO attempts
      (user_id, user_name, date, mode, wpm, raw_wpm, accuracy, consistency, correct, incorrect, duration, snapshots)
    VALUES
      (@userId, @userName, @date, @mode, @wpm, @rawWpm, @accuracy, @consistency, @correct, @incorrect, @duration, @snapshots)
  `);

  const info = stmt.run({
    userId: getClientId(req),
    userName: getClientName(req),
    date: date || new Date().toISOString(),
    mode,
    wpm, rawWpm, accuracy, consistency, correct, incorrect, duration,
    snapshots: JSON.stringify(Array.isArray(snapshots) ? snapshots : [])
  });

  res.status(201).json({ id: info.lastInsertRowid });
});

// Fetch recent attempts for this client, most recent first.
app.get("/api/attempts", (req, res) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 100, 500);
  const userId = getClientId(req);

  const rows = db.prepare(`
    SELECT id, date, mode, wpm, raw_wpm AS rawWpm, accuracy,
           consistency, correct, incorrect, duration, snapshots, user_name AS userName
    FROM attempts
    WHERE user_id = ?
    ORDER BY id DESC
    LIMIT ?
  `).all(userId, limit);

  const attempts = rows.map(r => ({ ...r, snapshots: JSON.parse(r.snapshots) }));
  res.json(attempts);
});

// Delete a single attempt — scoped to the requesting client so you can't
// delete someone else's row just by guessing an id.
app.delete("/api/attempts/:id", (req, res) => {
  const info = db.prepare("DELETE FROM attempts WHERE id = ? AND user_id = ?")
    .run(req.params.id, getClientId(req));
  if (info.changes === 0) return res.status(404).json({ error: "Not found" });
  res.status(204).end();
});

app.listen(PORT, () => {
  console.log(`OggyType server running at http://localhost:${PORT}`);
});
